# frozen_string_literal: true

class CSV
  # The version of the installed library.
  VERSION = "3.0.9"
end
